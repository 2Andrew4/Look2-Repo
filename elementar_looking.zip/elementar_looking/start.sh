#! /bin/bash
(
java -jar Look2.jar
) 
